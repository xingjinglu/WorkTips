class MyCell(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  dg : __torch__.___torch_mangle_72.MyDecisionGate
  linear : __torch__.torch.nn.modules.linear.___torch_mangle_79.Linear
  def forward(self: __torch__.___torch_mangle_80.MyCell,
    input: Tensor,
    h: Tensor) -> Tuple[Tensor, Tensor]:
    _0 = (self.dg).forward((self.linear).forward(input, ), )
    _1 = torch.tanh(torch.add(_0, h, alpha=1))
    return (_1, _1)
