class MyRNNLoop(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  cell : __torch__.___torch_mangle_80.MyCell
  def forward(self: __torch__.___torch_mangle_83.MyRNNLoop,
    xs: Tensor) -> Tuple[Tensor, Tensor]:
    h = torch.zeros([3, 4], dtype=None, layout=None, device=None, pin_memory=None)
    y = torch.zeros([3, 4], dtype=None, layout=None, device=None, pin_memory=None)
    y0 = y
    h0 = h
    for i in range(torch.size(xs, 0)):
      _0 = (self.cell).forward(torch.select(xs, 0, i), h0, )
      y1, h1, = _0
      y0, h0 = y1, h1
    return (y0, h0)
