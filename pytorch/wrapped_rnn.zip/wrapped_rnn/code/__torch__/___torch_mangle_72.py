class MyDecisionGate(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  def forward(self: __torch__.___torch_mangle_72.MyDecisionGate,
    x: Tensor) -> Tensor:
    _0 = torch.gt(torch.sum(x, dtype=None), 0)
    if bool(_0):
      _1 = x
    else:
      _1 = torch.neg(x)
    return _1
